export interface Method {
  id: string;
  title: string;
  shortDescription: string;
  fullDescription: string;
  steps: string[];
  isPremium: boolean;
  icon: string;
}

export const METHODS: Method[] = [
  {
    id: 'pomodoro',
    title: 'Tecnica del Pomodoro',
    shortDescription: 'Studia 25 minuti, riposa 5. Mantieni alta la concentrazione.',
    fullDescription: 'Il metodo Pomodoro ti aiuta a non stancarti. Usalo per compiti lunghi o noiosi.',
    steps: [
      'Imposta un timer di 25 minuti.',
      'Studia senza distrazioni.',
      'Fai 5 minuti di pausa.',
      'Ripeti.'
    ],
    isPremium: false,
    icon: 'Timer'
  },
  {
    id: 'feynman',
    title: 'Tecnica Feynman',
    shortDescription: 'Se sai spiegarlo in modo semplice, lo hai capito davvero.',
    fullDescription: 'Il modo migliore per imparare è fingere di insegnare l\'argomento a qualcun altro.',
    steps: [
      'Scegli un argomento.',
      'Spiegalo a voce alta come se parlassi a un bambino.',
      'Se ti blocchi, rileggi quella parte.',
      'Semplifica il linguaggio.'
    ],
    isPremium: false,
    icon: 'Brain'
  },
  {
    id: 'pareto',
    title: 'Principio 80/20',
    shortDescription: 'Studia il 20% delle cose che valgono l\'80% del voto.',
    fullDescription: 'Non tutto è importante uguale. Concentrati sugli argomenti fondamentali.',
    steps: [
      'Guarda i vecchi esami.',
      'Trova gli argomenti più frequenti.',
      'Studia prima quelli alla perfezione.',
      'Il resto solo dopo.'
    ],
    isPremium: false,
    icon: 'PieChart'
  },
  {
    id: 'single-sheet',
    title: 'Foglio Unico',
    shortDescription: 'Riassumi un intero capitolo su un solo foglio.',
    fullDescription: 'Ti costringe a sintetizzare e trovare i collegamenti logici tra i concetti.',
    steps: [
      'Leggi il capitolo.',
      'Prendi un foglio bianco.',
      'Scrivi solo le cose essenziali.',
      'Usa schemi e frecce.'
    ],
    isPremium: false,
    icon: 'FileText'
  },
  {
    id: 'spaced-repetition',
    title: 'Ripetizione Spaziata',
    shortDescription: 'Ripassa a intervalli crescenti per non dimenticare mai.',
    fullDescription: 'La memoria va rinfrescata appena prima di dimenticare.',
    steps: [
      'Studia oggi.',
      'Ripassa domani.',
      'Ripassa tra 3 giorni.',
      'Ripassa tra una settimana.'
    ],
    isPremium: false,
    icon: 'Repeat'
  },
  {
    id: 'active-recall',
    title: 'Active Recall',
    shortDescription: 'Mettiti alla prova invece di rileggere.',
    fullDescription: 'Rileggere è passivo. Rispondere a domande è attivo e fissa i ricordi.',
    steps: [
      'Chiudi il libro.',
      'Fatti una domanda.',
      'Rispondi a memoria.',
      'Controlla se hai fatto giusto.'
    ],
    isPremium: false,
    icon: 'Zap'
  },
  {
    id: 'cornell-advanced',
    title: 'Metodo Cornell',
    shortDescription: 'Prendi appunti ordinati e pronti per il ripasso.',
    fullDescription: 'Dividi il foglio per separare appunti, parole chiave e riassunto.',
    steps: [
      'Dividi il foglio in 3 parti.',
      'Note a destra durante la lezione.',
      'Parole chiave a sinistra dopo la lezione.',
      'Riassunto in basso.'
    ],
    isPremium: false,
    icon: 'BookOpen'
  },
  {
    id: 'smart-planning',
    title: 'Pianificazione',
    shortDescription: 'Organizza lo studio in base alla tua energia.',
    fullDescription: 'Studia le cose difficili quando sei più sveglio.',
    steps: [
      'Trova le tue ore migliori.',
      'Mettici le materie difficili.',
      'Pianifica anche il riposo.',
      'Lascia spazi vuoti per imprevisti.'
    ],
    isPremium: false,
    icon: 'Calendar'
  },
  {
    id: 'blurting',
    title: 'Blurting',
    shortDescription: 'Scrivi tutto quello che ricordi di getto.',
    fullDescription: 'Un ottimo modo per vedere cosa sai davvero e cosa no.',
    steps: [
      'Leggi un argomento.',
      'Chiudi tutto.',
      'Scrivi tutto quello che ricordi velocemente.',
      'Correggi con il libro.'
    ],
    isPremium: false,
    icon: 'Edit3'
  }
];
