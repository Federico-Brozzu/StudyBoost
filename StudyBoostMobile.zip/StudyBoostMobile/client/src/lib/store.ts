
interface User {
  email: string;
  name: string;
}

// Helper to safely access localStorage
const getStorage = (key: string, def: any) => {
  try {
    const val = localStorage.getItem(key);
    return val ? JSON.parse(val) : def;
  } catch {
    return def;
  }
};

const dispatchChange = () => {
  window.dispatchEvent(new Event('storage-change'));
};

export const storage = {
  getUser: (): User | null => getStorage('sb_user', null),
  setUser: (user: User | null) => {
    if (user) localStorage.setItem('sb_user', JSON.stringify(user));
    else localStorage.removeItem('sb_user');
    dispatchChange();
  },
  getPremium: (): boolean => getStorage('sb_premium', false),
  setPremium: (status: boolean) => {
    localStorage.setItem('sb_premium', JSON.stringify(status));
    dispatchChange();
  },
};
