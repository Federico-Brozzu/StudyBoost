import { Switch, Route } from "wouter";
import { Home } from "@/pages/Home";
import { Auth } from "@/pages/Auth";
import { Profile } from "@/pages/Profile";
import { Methods } from "@/pages/Methods";
import { MethodDetail } from "@/pages/MethodDetail";
import { Scanner } from "@/pages/Scanner";
import { Settings } from "@/pages/Settings";
import NotFound from "@/pages/not-found";
import { Toaster } from "@/components/ui/toaster";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/auth" component={Auth} />
      <Route path="/profile" component={Profile} />
      <Route path="/methods" component={Methods} />
      <Route path="/method/:id" component={MethodDetail} />
      <Route path="/scanner" component={Scanner} />
      <Route path="/settings" component={Settings} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <>
      <Router />
      <Toaster />
    </>
  );
}

export default App;
