import { ReactNode, useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { Zap, User, Home, BookOpen, Scan, Settings } from "lucide-react";
import { storage } from "@/lib/store";

export function Layout({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [user, setUser] = useState(storage.getUser());
  
  useEffect(() => {
    const handleStorageChange = () => setUser(storage.getUser());
    window.addEventListener('storage-change', handleStorageChange);
    return () => window.removeEventListener('storage-change', handleStorageChange);
  }, []);

  // Always show bottom nav for app-like experience, regardless of login state
  const showNav = true;

  const navItems = [
    { href: "/", icon: Home, label: "Home" },
    { href: "/methods", icon: BookOpen, label: "Metodi" },
    { href: "/scanner", icon: Scan, label: "Scanner" },
    { href: "/profile", icon: User, label: "Profilo" },
    { href: "/settings", icon: Settings, label: "Opzioni" },
  ];

  return (
    <div className="min-h-screen bg-background font-sans text-foreground flex flex-col pb-20 md:pb-0">
      {/* Mobile Header - Visible only on mobile to show app name separately */}
      <header className="sticky top-0 z-50 w-full bg-background/95 backdrop-blur-md border-b border-border/50 md:hidden">
        <div className="flex items-center justify-center h-14">
          <div className="flex items-center gap-2 text-primary">
            <div className="p-1 bg-primary/10 rounded-lg">
              <BookOpen className="h-5 w-5" />
            </div>
            <span className="font-heading font-bold text-lg tracking-tight text-foreground">StudyBoost</span>
          </div>
        </div>
      </header>

      {/* Desktop Header */}
      <header className="sticky top-0 z-50 w-full border-b border-white/10 bg-slate-900 text-white shadow-lg hidden md:block">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 hover:opacity-90 transition-opacity">
            <Zap className="h-6 w-6 text-primary" />
            <span className="text-xl font-heading font-bold tracking-tight">StudyBoost</span>
          </Link>
          {/* Desktop Nav could be added here if needed */}
        </div>
      </header>
      
      <main className="flex-1 container mx-auto px-4 py-6 md:py-12 max-w-md md:max-w-4xl w-full self-center">
        {children}
      </main>

      {/* Bottom Navigation Bar */}
      {showNav && (
        <nav className="fixed bottom-0 left-0 right-0 bg-card/95 backdrop-blur-md border-t border-border z-[100] pb-safe shadow-[0_-4px_20px_rgba(0,0,0,0.05)]">
          <div className="flex justify-around items-center h-16 max-w-md mx-auto px-2">
            {navItems.map((item) => {
              const isActive = location === item.href;
              return (
                <Link key={item.href} href={item.href}>
                  <div className="flex flex-col items-center justify-center w-full h-full space-y-1 cursor-pointer group relative">
                    {isActive && (
                      <div className="absolute -top-[1px] left-1/2 -translate-x-1/2 w-8 h-1 bg-primary rounded-b-full shadow-[0_2px_10px_rgba(57,255,20,0.5)]"></div>
                    )}
                    <item.icon 
                      className={`h-6 w-6 transition-all duration-300 ${isActive ? 'text-primary -translate-y-0.5' : 'text-muted-foreground group-hover:text-foreground group-active:scale-95'}`} 
                      strokeWidth={isActive ? 2.5 : 2}
                    />
                    <span className={`text-[10px] font-medium transition-colors ${isActive ? 'text-foreground' : 'text-muted-foreground'}`}>
                      {item.label}
                    </span>
                  </div>
                </Link>
              );
            })}
          </div>
        </nav>
      )}
    </div>
  );
}
