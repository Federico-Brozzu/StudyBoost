import { useState, useEffect } from "react";
import { Layout } from "@/components/Layout";
import { storage } from "@/lib/store";
import { Moon, Sun, LogOut, Monitor } from "lucide-react";
import { useLocation } from "wouter";

export function Settings() {
  const [, setLocation] = useLocation();
  const [theme, setTheme] = useState<'light' | 'dark'>('light');

  useEffect(() => {
    if (document.documentElement.classList.contains('dark')) {
      setTheme('dark');
    }
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    if (newTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('theme', newTheme);
  };

  const handleLogout = () => {
    storage.setUser(null);
    setLocation("/");
  };

  return (
    <Layout>
      <div className="space-y-6">
        <h1 className="text-3xl font-heading font-bold">Impostazioni</h1>

        <div className="space-y-4">
          {/* Theme Toggle */}
          <div className="bg-card border border-border rounded-xl p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              {theme === 'dark' ? <Moon className="h-5 w-5 text-primary" /> : <Sun className="h-5 w-5 text-amber-500" />}
              <div>
                <div className="font-bold">Tema Scuro</div>
                <div className="text-xs text-muted-foreground">Cambia l'aspetto dell'app</div>
              </div>
            </div>
            <button 
              onClick={toggleTheme}
              className={`w-12 h-6 rounded-full transition-colors relative ${theme === 'dark' ? 'bg-primary' : 'bg-slate-200'}`}
            >
              <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow-sm transition-transform ${theme === 'dark' ? 'left-7' : 'left-1'}`} />
            </button>
          </div>

          {/* Logout */}
          <button 
            onClick={handleLogout}
            className="w-full bg-destructive/10 text-destructive font-bold py-4 rounded-xl flex items-center justify-center gap-2 hover:bg-destructive/20 transition-colors"
          >
            <LogOut className="h-5 w-5" />
            Esci dall'account
          </button>
          
          <div className="text-center text-xs text-muted-foreground pt-4">
            Versione 1.0.2 • Build 2025
          </div>
        </div>
      </div>
    </Layout>
  );
}
