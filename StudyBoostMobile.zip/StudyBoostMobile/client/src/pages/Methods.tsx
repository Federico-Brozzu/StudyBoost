import { Link } from "wouter";
import { Layout } from "@/components/Layout";
import { METHODS, Method } from "@/data/methods";
import { ChevronRight, Timer, Brain, PieChart, FileText, Repeat, Zap, BookOpen, Calendar, Edit3 } from "lucide-react";

// Icon mapping
const iconMap: Record<string, any> = {
  Timer, Brain, PieChart, FileText, Repeat, Zap, BookOpen, Calendar, Edit3
};

export function Methods() {
  return (
    <Layout>
      <div className="space-y-10 pb-20">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-heading font-bold">Metodi di Studio</h1>
          <p className="text-muted-foreground">Scegli la tecnica più adatta a te.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {METHODS.map((method) => (
            <MethodCard key={method.id} method={method} />
          ))}
        </div>
      </div>
    </Layout>
  );
}

function MethodCard({ method }: { method: Method }) {
  const Icon = iconMap[method.icon] || FileText;
  
  return (
    <Link href={`/method/${method.id}`}>
      <div className="h-full p-5 rounded-xl border border-border bg-card shadow-sm transition-all hover:shadow-md hover:border-primary/50 group cursor-pointer flex flex-col">
        <div className="flex justify-between items-start mb-3">
          <div className="p-2 rounded-lg bg-primary/10 text-primary">
            <Icon className="h-6 w-6" />
          </div>
          <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
        </div>
        <h3 className="font-bold text-lg mb-1">{method.title}</h3>
        <p className="text-sm text-muted-foreground line-clamp-3 flex-1">{method.shortDescription}</p>
      </div>
    </Link>
  );
}
