import { useLocation } from "wouter";
import { Layout } from "@/components/Layout";
import { storage } from "@/lib/store";
import { User as UserIcon, Calendar, Mail } from "lucide-react";
import { useEffect, useState } from "react";

export function Profile() {
  const [, setLocation] = useLocation();
  const [user, setUser] = useState(storage.getUser());

  useEffect(() => {
    if (!user) {
      setLocation("/auth");
    }
  }, [user, setLocation]);

  if (!user) return null;

  // Mock join date
  const joinDate = "05 Dicembre 2025";

  return (
    <Layout>
      <div className="space-y-8">
        <h1 className="text-3xl font-heading font-bold">Profilo</h1>

        <div className="bg-card border border-border rounded-xl p-6 shadow-sm flex flex-col items-center text-center space-y-4">
          <div className="h-24 w-24 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center border-4 border-primary/20">
            <UserIcon className="h-12 w-12 text-slate-400" />
          </div>
          
          <div>
            <h2 className="text-2xl font-bold">{user.name}</h2>
            <p className="text-muted-foreground">Studente</p>
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl divide-y divide-border">
          <div className="p-4 flex items-center gap-4">
            <div className="p-2 bg-primary/10 text-primary rounded-lg">
              <Mail className="h-5 w-5" />
            </div>
            <div>
              <div className="text-xs text-muted-foreground uppercase font-bold tracking-wider">Email</div>
              <div className="font-medium">{user.email}</div>
            </div>
          </div>
          
          <div className="p-4 flex items-center gap-4">
            <div className="p-2 bg-primary/10 text-primary rounded-lg">
              <Calendar className="h-5 w-5" />
            </div>
            <div>
              <div className="text-xs text-muted-foreground uppercase font-bold tracking-wider">Membro dal</div>
              <div className="font-medium">{joinDate}</div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
