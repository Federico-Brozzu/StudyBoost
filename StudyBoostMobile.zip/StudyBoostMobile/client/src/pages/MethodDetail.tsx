import { useRoute, Link } from "wouter";
import { Layout } from "@/components/Layout";
import { METHODS } from "@/data/methods";
import { ArrowLeft, CheckCircle } from "lucide-react";
import { motion } from "framer-motion";

export function MethodDetail() {
  const [match, params] = useRoute("/method/:id");
  const method = match ? METHODS.find(m => m.id === params.id) : null;

  if (!method) {
    return (
      <Layout>
        <div className="text-center py-20">
          <h1 className="text-2xl font-bold mb-4">Metodo non trovato</h1>
          <Link href="/methods">
            <span className="text-primary hover:underline cursor-pointer">Torna ai metodi</span>
          </Link>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-8 pb-20">
        <Link href="/methods">
          <button className="flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors mb-4">
            <ArrowLeft className="h-4 w-4" /> Torna alla lista
          </button>
        </Link>

        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <div className="space-y-4 border-b border-border pb-8">
            <h1 className="text-3xl md:text-5xl font-heading font-extrabold tracking-tight text-slate-900 dark:text-white">
              {method.title}
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed max-w-2xl">
              {method.shortDescription}
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
            <div className="lg:col-span-2 space-y-8">
              <div className="prose prose-slate dark:prose-invert max-w-none">
                <h3 className="text-2xl font-bold mb-4">Come funziona</h3>
                <p className="text-lg leading-relaxed text-slate-700 dark:text-slate-300">
                  {method.fullDescription}
                </p>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-6 md:p-8 border border-border">
                <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                  <span className="bg-primary text-primary-foreground h-6 w-6 rounded-full flex items-center justify-center text-xs font-bold">!</span>
                  Passi da seguire
                </h3>
                <ul className="space-y-4">
                  {method.steps.map((step, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                      <span className="text-slate-700 dark:text-slate-200 font-medium">{step}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="lg:col-span-1">
              <div className="sticky top-24 space-y-6">
                <div className="bg-primary/5 rounded-xl p-6 border border-primary/20">
                  <h4 className="font-bold text-lg mb-2 text-primary-foreground dark:text-primary">Perché funziona?</h4>
                  <p className="text-sm text-muted-foreground">
                    Questo metodo sfrutta principi cognitivi dimostrati per massimizzare la ritenzione a lungo termine e ridurre il carico cognitivo.
                  </p>
                </div>
                
                <div className="bg-card rounded-xl p-6 border border-border shadow-sm">
                  <h4 className="font-bold mb-4">Altri metodi suggeriti</h4>
                  <div className="space-y-3">
                    {METHODS.filter(m => m.id !== method.id).slice(0, 3).map(rel => (
                      <Link key={rel.id} href={`/method/${rel.id}`}>
                        <div className="block p-3 rounded-lg hover:bg-accent transition-colors cursor-pointer text-sm font-medium">
                          {rel.title}
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </Layout>
  );
}
