import { useState, useRef } from "react";
import { Layout } from "@/components/Layout";
import { Upload, FileText, Network, Camera, X, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

export function Scanner() {
  const [images, setImages] = useState<string[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<{ type: 'summary' | 'map', content: any } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newImages = Array.from(e.target.files).map(file => URL.createObjectURL(file));
      setImages(prev => [...prev, ...newImages]);
    }
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const simulateAI = (type: 'summary' | 'map') => {
    if (images.length === 0) {
      toast({
        title: "Nessuna immagine",
        description: "Carica almeno una foto per iniziare.",
        variant: "destructive"
      });
      return;
    }

    setIsProcessing(true);
    setResult(null);

    // Simulate API call delay
    setTimeout(() => {
      setIsProcessing(false);
      if (type === 'summary') {
        setResult({
          type: 'summary',
          content: "In questo testo viene analizzato il concetto di efficienza nello studio. I punti principali riguardano: 1) L'importanza delle pause regolari (Tecnica del Pomodoro); 2) La necessità di testarsi attivamente (Active Recall); 3) L'organizzazione basata sui ritmi circadiani. L'autore suggerisce di evitare il multitasking e di concentrarsi su una singola attività alla volta per massimizzare la ritenzione delle informazioni."
        });
      } else {
        setResult({
          type: 'map',
          content: {
            title: "Efficienza nello Studio",
            branches: [
              {
                name: "Gestione Tempo",
                points: ["Pomodoro (25+5)", "Pianificazione blocchi", "Pause strategiche"]
              },
              {
                name: "Tecniche Memoria",
                points: ["Active Recall", "Ripetizione Spaziata", "Associazioni mentali"]
              },
              {
                name: "Salute Mentale",
                points: ["Sonno adeguato", "Gestione stress", "Obiettivi realistici"]
              }
            ]
          }
        });
      }
    }, 2000);
  };

  return (
    <Layout>
      <div className="space-y-6 pb-24">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-heading font-bold">Scanner AI</h1>
          <p className="text-muted-foreground">Carica i tuoi appunti e lascia fare all'AI.</p>
        </div>

        {/* Upload Area */}
        <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
          <div className="grid grid-cols-3 gap-2 mb-4">
            {images.map((src, idx) => (
              <div key={idx} className="relative aspect-square rounded-lg overflow-hidden border border-border group">
                <img src={src} alt="Upload" className="w-full h-full object-cover" />
                <button 
                  onClick={() => removeImage(idx)}
                  className="absolute top-1 right-1 bg-black/50 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            ))}
            {images.length < 10 && (
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="aspect-square rounded-lg border-2 border-dashed border-border flex flex-col items-center justify-center gap-2 text-muted-foreground hover:bg-accent/50 transition-colors"
              >
                <Camera className="h-6 w-6" />
                <span className="text-xs font-medium">Aggiungi</span>
              </button>
            )}
          </div>

          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            accept="image/*" 
            multiple 
            onChange={handleImageUpload} 
          />

          <div className="flex gap-3">
            <button 
              onClick={() => simulateAI('summary')}
              disabled={isProcessing || images.length === 0}
              className="flex-1 py-3 rounded-lg bg-primary text-primary-foreground font-bold flex items-center justify-center gap-2 hover:brightness-110 transition-all disabled:opacity-50"
            >
              {isProcessing ? <Loader2 className="animate-spin h-4 w-4" /> : <FileText className="h-4 w-4" />}
              Riassunto
            </button>
            <button 
              onClick={() => simulateAI('map')}
              disabled={isProcessing || images.length === 0}
              className="flex-1 py-3 rounded-lg bg-slate-800 text-white font-bold flex items-center justify-center gap-2 hover:bg-slate-700 transition-all disabled:opacity-50"
            >
              {isProcessing ? <Loader2 className="animate-spin h-4 w-4" /> : <Network className="h-4 w-4" />}
              Mappa
            </button>
          </div>
        </div>

        {/* Results Area */}
        {result && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-card border border-border rounded-xl p-6 shadow-sm"
          >
            <h3 className="font-bold text-xl mb-4 flex items-center gap-2">
              {result.type === 'summary' ? <FileText className="text-primary" /> : <Network className="text-primary" />}
              Risultato AI
            </h3>
            
            {result.type === 'summary' ? (
              <p className="leading-relaxed text-muted-foreground">{result.content}</p>
            ) : (
              <div className="space-y-4">
                <div className="font-bold text-lg text-center p-2 bg-accent/50 rounded-lg">{result.content.title}</div>
                <div className="grid gap-4">
                  {result.content.branches.map((branch: any, idx: number) => (
                    <div key={idx} className="border-l-2 border-primary pl-4">
                      <div className="font-bold text-foreground mb-1">{branch.name}</div>
                      <ul className="list-disc list-inside text-sm text-muted-foreground">
                        {branch.points.map((point: string, pIdx: number) => (
                          <li key={pIdx}>{point}</li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        )}
      </div>
    </Layout>
  );
}
