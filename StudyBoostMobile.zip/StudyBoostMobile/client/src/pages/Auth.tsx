import { useState } from "react";
import { useLocation } from "wouter";
import { Layout } from "@/components/Layout";
import { storage } from "@/lib/store";
import { Loader2 } from "lucide-react";
import { motion } from "framer-motion";

export function Auth() {
  const [isLogin, setIsLogin] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [, setLocation] = useLocation();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate API delay
    setTimeout(() => {
      const user = {
        email,
        name: isLogin ? (storage.getUser()?.name || email.split('@')[0]) : name
      };
      
      storage.setUser(user);
      setIsLoading(false);
      setLocation("/profile");
    }, 1000);
  };

  return (
    <Layout>
      <div className="flex items-center justify-center min-h-[60vh]">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-md p-8 rounded-2xl border border-border bg-card shadow-xl"
        >
          <div className="text-center mb-8">
            <h2 className="text-3xl font-heading font-bold mb-2">
              {isLogin ? "Bentornato" : "Crea Account"}
            </h2>
            <p className="text-muted-foreground">
              {isLogin ? "Inserisci le tue credenziali per accedere." : "Inizia il tuo viaggio verso l'eccellenza."}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div className="space-y-2">
                <label className="text-sm font-medium">Nome</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 rounded-md border border-input bg-background focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all"
                  placeholder="Il tuo nome"
                />
              </div>
            )}
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-input bg-background focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all"
                placeholder="tuo@email.com"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Password</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-input bg-background focus:ring-2 focus:ring-primary/50 focus:border-primary outline-none transition-all"
                placeholder="••••••••"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full neon-button py-3 rounded-md mt-6 flex items-center justify-center"
            >
              {isLoading ? <Loader2 className="animate-spin h-5 w-5" /> : (isLogin ? "Accedi" : "Registrati")}
            </button>
          </form>

          <div className="mt-6 text-center text-sm">
            <span className="text-muted-foreground">
              {isLogin ? "Non hai un account? " : "Hai già un account? "}
            </span>
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="text-primary font-bold hover:underline"
            >
              {isLogin ? "Registrati" : "Accedi"}
            </button>
          </div>
        </motion.div>
      </div>
    </Layout>
  );
}
