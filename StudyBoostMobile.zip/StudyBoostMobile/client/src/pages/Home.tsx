import { Link } from "wouter";
import { Layout } from "@/components/Layout";
import { Scan, FileText, Network, BookOpen, ArrowRight, CheckCircle2, Zap, Smartphone, BarChart3 } from "lucide-react";
import { motion } from "framer-motion";

export function Home() {
  return (
    <Layout>
      <div className="space-y-8 pb-24">
        {/* Hero Banner */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 via-purple-600 to-slate-900 text-white p-6 md:p-10 shadow-xl border border-white/10">
          
          {/* Logo removed from here as requested, moved to separate header */}

          <div className="relative z-10 mt-4 space-y-6 text-center">
            <h1 className="text-3xl md:text-5xl font-heading font-extrabold tracking-tight leading-tight drop-shadow-sm">
              Studia meno,<br />
              <span className="text-emerald-300">capisci di più.</span>
            </h1>
            
            {/* Main CTA Scanner */}
            <div className="flex justify-center pt-2">
              <Link href="/scanner">
                <button className="group relative w-full max-w-sm bg-white text-indigo-600 hover:bg-indigo-50 font-bold text-lg py-4 px-6 rounded-2xl shadow-lg transition-all transform hover:-translate-y-1 active:translate-y-0 flex items-center justify-center gap-3">
                  <div className="bg-indigo-100 p-2 rounded-full">
                    <Scan className="h-6 w-6" />
                  </div>
                  <div className="flex flex-col items-start leading-tight">
                    <span>Apri Scanner</span>
                    <span className="text-[10px] font-medium text-indigo-400 uppercase tracking-wider">
                      FOTO → RIASSUNTO / MAPPA
                    </span>
                  </div>
                  <ArrowRight className="h-5 w-5 absolute right-6 text-indigo-300 opacity-0 group-hover:opacity-100 transition-all translate-x-2 group-hover:translate-x-0" />
                </button>
              </Link>
            </div>
          </div>
          
          {/* Decorative background elements */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-purple-500/30 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-indigo-500/30 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2 pointer-events-none"></div>
        </div>

        {/* Shortcuts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 px-1">
          <ShortcutCard 
            href="/scanner"
            icon={FileText}
            title="Riassumere da foto"
            color="text-blue-600"
            bgColor="bg-blue-50"
          />
          <ShortcutCard 
            href="/scanner"
            icon={Network}
            title="Generare mappa"
            color="text-purple-600"
            bgColor="bg-purple-50"
          />
          <ShortcutCard 
            href="/methods"
            icon={BookOpen}
            title="Metodi di studio"
            color="text-emerald-600"
            bgColor="bg-emerald-50"
          />
        </div>

        {/* Key Points Section */}
        <div className="space-y-4 pt-4">
          <h2 className="text-xl font-heading font-bold px-2">Punti chiave dell'app</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <FeaturePoint icon={FileText} text="Crea riassunti dalle tue foto" />
            <FeaturePoint icon={Network} text="Genera mappe concettuali automatiche" />
            <FeaturePoint icon={BookOpen} text="Accedi ai metodi di studio" />
            <FeaturePoint icon={BarChart3} text="Tieni traccia dei tuoi progressi" />
            <FeaturePoint icon={Smartphone} text="Usa l'app da telefono o tablet senza limiti" />
          </div>
        </div>
      </div>
    </Layout>
  );
}

function ShortcutCard({ href, icon: Icon, title, color, bgColor }: { href: string, icon: any, title: string, color: string, bgColor: string }) {
  return (
    <Link href={href}>
      <div className="flex items-center p-4 rounded-2xl bg-card border border-border/50 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all cursor-pointer group">
        <div className={`p-3 rounded-xl mr-4 ${bgColor} ${color} group-hover:scale-110 transition-transform`}>
          <Icon className="h-6 w-6" />
        </div>
        <div className="flex-1">
          <h3 className="font-bold text-foreground text-sm md:text-base">{title}</h3>
        </div>
        <div className="text-muted-foreground/50 group-hover:translate-x-1 transition-transform">
          <ArrowRight className="h-4 w-4" />
        </div>
      </div>
    </Link>
  );
}

function FeaturePoint({ icon: Icon, text }: { icon: any, text: string }) {
  return (
    <div className="flex items-center gap-3 p-4 rounded-xl bg-card/50 border border-border/40 hover:bg-card transition-colors">
      <Icon className="h-5 w-5 text-primary shrink-0" />
      <span className="text-sm font-medium text-muted-foreground">{text}</span>
    </div>
  );
}
